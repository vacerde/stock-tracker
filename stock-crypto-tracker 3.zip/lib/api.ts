// API configuration and utilities for real market data
const ALPHA_VANTAGE_API_KEY = process.env.NEXT_PUBLIC_ALPHA_VANTAGE_API_KEY || "demo"
const COINGECKO_API_URL = "https://api.coingecko.com/api/v3"
const NEWS_API_KEY = process.env.NEXT_PUBLIC_NEWS_API_KEY || "demo"

export interface StockData {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  volume: number
  marketCap: number
  high52Week: number
  low52Week: number
  pe: number
  eps: number
  dividend: number
  beta: number
}

export interface CryptoData {
  id: string
  symbol: string
  name: string
  price: number
  change24h: number
  changePercent24h: number
  volume24h: number
  marketCap: number
  high24h: number
  low24h: number
  circulatingSupply: number
  totalSupply: number
}

export interface NewsItem {
  id: string
  title: string
  description: string
  url: string
  source: string
  publishedAt: string
  category: string
  sentiment?: "positive" | "negative" | "neutral"
}

export interface ChartData {
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

// Stock API functions
export async function getStockData(symbol: string): Promise<StockData> {
  try {
    const response = await fetch(
      `https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=${symbol}&apikey=${ALPHA_VANTAGE_API_KEY}`,
    )
    const data = await response.json()

    if (data["Error Message"]) {
      throw new Error("Stock not found")
    }

    const quote = data["Global Quote"]
    return {
      symbol: quote["01. symbol"],
      name: symbol, // You'd need another API call for company name
      price: Number.parseFloat(quote["05. price"]),
      change: Number.parseFloat(quote["09. change"]),
      changePercent: Number.parseFloat(quote["10. change percent"].replace("%", "")),
      volume: Number.parseInt(quote["06. volume"]),
      marketCap: 0, // Would need additional API call
      high52Week: Number.parseFloat(quote["03. high"]),
      low52Week: Number.parseFloat(quote["04. low"]),
      pe: 0,
      eps: 0,
      dividend: 0,
      beta: 0,
    }
  } catch (error) {
    console.error("Error fetching stock data:", error)
    throw error
  }
}

export async function getStockChart(symbol: string, interval = "daily"): Promise<ChartData[]> {
  try {
    const functionMap = {
      "1min": "TIME_SERIES_INTRADAY",
      "5min": "TIME_SERIES_INTRADAY",
      "15min": "TIME_SERIES_INTRADAY",
      "30min": "TIME_SERIES_INTRADAY",
      "60min": "TIME_SERIES_INTRADAY",
      daily: "TIME_SERIES_DAILY",
      weekly: "TIME_SERIES_WEEKLY",
      monthly: "TIME_SERIES_MONTHLY",
    }

    const func = functionMap[interval as keyof typeof functionMap] || "TIME_SERIES_DAILY"
    let url = `https://www.alphavantage.co/query?function=${func}&symbol=${symbol}&apikey=${ALPHA_VANTAGE_API_KEY}`

    if (func === "TIME_SERIES_INTRADAY") {
      url += `&interval=${interval}`
    }

    const response = await fetch(url)
    const data = await response.json()

    const timeSeriesKey = Object.keys(data).find((key) => key.includes("Time Series"))
    if (!timeSeriesKey) {
      throw new Error("No time series data found")
    }

    const timeSeries = data[timeSeriesKey]
    return Object.entries(timeSeries)
      .map(([timestamp, values]: [string, any]) => ({
        timestamp: new Date(timestamp).getTime(),
        open: Number.parseFloat(values["1. open"]),
        high: Number.parseFloat(values["2. high"]),
        low: Number.parseFloat(values["3. low"]),
        close: Number.parseFloat(values["4. close"]),
        volume: Number.parseInt(values["5. volume"]),
      }))
      .reverse()
  } catch (error) {
    console.error("Error fetching stock chart:", error)
    throw error
  }
}

// Crypto API functions
export async function getCryptoData(id: string): Promise<CryptoData> {
  try {
    const response = await fetch(
      `${COINGECKO_API_URL}/coins/${id}?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false`,
    )
    const data = await response.json()

    return {
      id: data.id,
      symbol: data.symbol.toUpperCase(),
      name: data.name,
      price: data.market_data.current_price.usd,
      change24h: data.market_data.price_change_24h,
      changePercent24h: data.market_data.price_change_percentage_24h,
      volume24h: data.market_data.total_volume.usd,
      marketCap: data.market_data.market_cap.usd,
      high24h: data.market_data.high_24h.usd,
      low24h: data.market_data.low_24h.usd,
      circulatingSupply: data.market_data.circulating_supply,
      totalSupply: data.market_data.total_supply,
    }
  } catch (error) {
    console.error("Error fetching crypto data:", error)
    throw error
  }
}

export async function getCryptoChart(id: string, days = 30): Promise<ChartData[]> {
  try {
    const response = await fetch(`${COINGECKO_API_URL}/coins/${id}/ohlc?vs_currency=usd&days=${days}`)
    const data = await response.json()

    return data.map((item: number[]) => ({
      timestamp: item[0],
      open: item[1],
      high: item[2],
      low: item[3],
      close: item[4],
      volume: 0, // OHLC endpoint doesn't include volume
    }))
  } catch (error) {
    console.error("Error fetching crypto chart:", error)
    throw error
  }
}

export async function getTopStocks(): Promise<StockData[]> {
  // This would typically use a different endpoint for top stocks
  const symbols = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", "META", "NVDA", "NFLX"]
  const promises = symbols.map((symbol) => getStockData(symbol).catch(() => null))
  const results = await Promise.all(promises)
  return results.filter(Boolean) as StockData[]
}

export async function getTopCryptos(): Promise<CryptoData[]> {
  try {
    const response = await fetch(
      `${COINGECKO_API_URL}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=20&page=1&sparkline=false`,
    )
    const data = await response.json()

    return data.map((coin: any) => ({
      id: coin.id,
      symbol: coin.symbol.toUpperCase(),
      name: coin.name,
      price: coin.current_price,
      change24h: coin.price_change_24h,
      changePercent24h: coin.price_change_percentage_24h,
      volume24h: coin.total_volume,
      marketCap: coin.market_cap,
      high24h: coin.high_24h,
      low24h: coin.low_24h,
      circulatingSupply: coin.circulating_supply,
      totalSupply: coin.total_supply,
    }))
  } catch (error) {
    console.error("Error fetching top cryptos:", error)
    throw error
  }
}

export async function getMarketNews(category = "general"): Promise<NewsItem[]> {
  try {
    const response = await fetch(
      `https://newsapi.org/v2/top-headlines?category=business&country=us&apiKey=${NEWS_API_KEY}`,
    )
    const data = await response.json()

    return (
      data.articles?.map((article: any, index: number) => ({
        id: `${index}`,
        title: article.title,
        description: article.description,
        url: article.url,
        source: article.source.name,
        publishedAt: article.publishedAt,
        category: "business",
      })) || []
    )
  } catch (error) {
    console.error("Error fetching news:", error)
    return []
  }
}

export async function searchAssets(query: string): Promise<{ stocks: StockData[]; cryptos: CryptoData[] }> {
  try {
    // Search stocks
    const stockResponse = await fetch(
      `https://www.alphavantage.co/query?function=SYMBOL_SEARCH&keywords=${query}&apikey=${ALPHA_VANTAGE_API_KEY}`,
    )
    const stockData = await stockResponse.json()

    // Search cryptos
    const cryptoResponse = await fetch(`${COINGECKO_API_URL}/search?query=${query}`)
    const cryptoData = await cryptoResponse.json()

    const stocks =
      stockData.bestMatches?.slice(0, 5).map((match: any) => ({
        symbol: match["1. symbol"],
        name: match["2. name"],
        price: 0,
        change: 0,
        changePercent: 0,
        volume: 0,
        marketCap: 0,
        high52Week: 0,
        low52Week: 0,
        pe: 0,
        eps: 0,
        dividend: 0,
        beta: 0,
      })) || []

    const cryptos =
      cryptoData.coins?.slice(0, 5).map((coin: any) => ({
        id: coin.id,
        symbol: coin.symbol.toUpperCase(),
        name: coin.name,
        price: 0,
        change24h: 0,
        changePercent24h: 0,
        volume24h: 0,
        marketCap: 0,
        high24h: 0,
        low24h: 0,
        circulatingSupply: 0,
        totalSupply: 0,
      })) || []

    return { stocks, cryptos }
  } catch (error) {
    console.error("Error searching assets:", error)
    return { stocks: [], cryptos: [] }
  }
}
